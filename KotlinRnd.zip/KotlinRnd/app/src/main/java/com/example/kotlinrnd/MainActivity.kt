package com.example.kotlinrnd

import android.content.Context
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.WindowManager
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize a new instance of AsyncTask class
        val task = AsyncTask(this,root_layout,progress_bar,text_view)


        // Button to start multiple images download
        button_start.setOnClickListener{
            task.execute(
                "https://images.freeimages.com/images/large-previews/310/spring-1-1405906.jpg",
                "https://images.freeimages.com/images/large-previews/8f3/white-flower-power-1403046.jpg",
                "https://images.freeimages.com/images/large-previews/81c/flower-1393311.jpg",
                "https://images.freeimages.com/images/large-previews/7f7/statice-1406388.jpg",
                "https://images.freeimages.com/images/large-previews/760/wedding-flower-1188350.jpg"
            )

            it.isEnabled = false
            button_cancel.isEnabled = true
        }


        // Button to cancel the async task
        button_cancel.setOnClickListener{
            task.cancel(true)
            it.isEnabled = false
        }


        // Set a click listener for root layout
        root_layout.setOnClickListener{
            // Get the async task status and show it using toast message
            when(task.status){
                AsyncTask.Status.RUNNING -> toast("Task running")
                AsyncTask.Status.PENDING -> toast("Task pending")
                AsyncTask.Status.FINISHED -> toast("Task finished")
                else -> toast("Task status Unknown")
            }
        }
    }


    // Extension function to show toast message
    fun Context.toast(message:String){
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show()
    }
}